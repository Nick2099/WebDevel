import React from "react";

function Additems() {
    return (
        <div>
            <h1>Add items!</h1>
        </div>
    );
}

export default Additems;