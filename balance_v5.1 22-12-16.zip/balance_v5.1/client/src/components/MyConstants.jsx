const MyConstant = {
    minimumLengthForName: 2,
    minimumLengthForFamily: 2,
    minimumLengthOfPassword: 8,
    maximumNrOfLocalUsersStandard: 3,
    maximumNrOfLocalUsersPremium: 15,
    maximumNrOfLinesInEntryStandard: 10,
    maximumNrOfLinesInEntryPremium: 50
};
export { MyConstant};