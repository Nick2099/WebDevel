import React from 'react';
// import {render} from 'react-dom';
import App from './App';

import ReactDOM from 'react-dom/client';

ReactDOM.createRoot(
    document.getElementById("root"),
  )
  .render(
      <App />,
      );
      
/*
<React.StrictMode>
</React.StrictMode>,
*/